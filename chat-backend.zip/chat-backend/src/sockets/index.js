const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');
const Message = require('../models/Message');
const Conversation = require('../models/Conversation');
const User = require('../models/User');
const { createClient } = require('redis');

let io;

async function initSockets(server){
  io = new Server(server, {
    cors: { origin: '*' }
  });

  // If you run multiple instances, configure adapter with Redis (example below)
  if(process.env.REDIS_URL){
    const { createAdapter } = require('@socket.io/redis-adapter');
    const pubClient = createClient({ url: process.env.REDIS_URL });
    const subClient = pubClient.duplicate();
    await pubClient.connect();
    await subClient.connect();
    io.adapter(createAdapter(pubClient, subClient));
  }

  io.use(async (socket, next) => {
    const token = socket.handshake.auth?.token;
    if(!token) return next(new Error('Authentication error'));
    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET || 'super-secret-jwt');
      const user = await User.findById(payload.id).select('-passwordHash');
      if(!user) return next(new Error('User not found'));
      socket.user = user;
      return next();
    } catch (e) {
      return next(new Error('Authentication error'));
    }
  });

  io.on('connection', (socket) => {
    console.log('user connected', socket.user._id.toString());
    // Join rooms for each conversation participant belongs to (or client should emit join)
    socket.on('joinConversation', async (conversationId) => {
      const conv = await Conversation.findById(conversationId);
      if(!conv) return socket.emit('error', 'Conversation not found');
      const isParticipant = conv.participants.find(id => id.toString() === socket.user._id.toString());
      if(!isParticipant) return socket.emit('error', 'Not a participant');
      socket.join(`conv_${conversationId}`);
    });

    // Handle sending message via socket
    socket.on('sendMessage', async (payload) => {
      // payload: { conversationId, body, type }
      const { conversationId, body, type='text' } = payload;
      const conv = await Conversation.findById(conversationId);
      if(!conv) return socket.emit('error', 'Conversation not found');
      const isParticipant = conv.participants.find(id => id.toString() === socket.user._id.toString());
      if(!isParticipant) return socket.emit('error', 'Not a participant');

      const message = new Message({
        conversation: conversationId,
        sender: socket.user._id,
        body,
        type
      });
      await message.save();
      const populated = await message.populate('sender', 'name phone avatarUrl');

      // Emit to all in room
      io.to(`conv_${conversationId}`).emit('message', populated);

      // Optionally: send push notifications to offline participants (placeholder)
      // TODO: check online status and send push to offline users
    });

    // Typing indicator
    socket.on('typing', ({ conversationId, typing }) => {
      socket.to(`conv_${conversationId}`).emit('typing', { userId: socket.user._id, typing });
    });

    socket.on('disconnect', () => {
      console.log('user disconnected', socket.user._id.toString());
    });
  });
}

module.exports = { initSockets };