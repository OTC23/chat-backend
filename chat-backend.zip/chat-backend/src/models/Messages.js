const mongoose = require('mongoose');

const MessageSchema = new mongoose.Schema({
  conversation: { type: mongoose.Schema.Types.ObjectId, ref: 'Conversation', required: true, index: true },
  sender: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  body: { type: String }, // plaintext or ciphertext
  media: { type: String }, // media URL
  type: { type: String, enum: ['text','image','video','audio','file','system'], default: 'text' },
  deliveredTo: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // who got delivered
  readBy: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }], // who read
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Message', MessageSchema);