require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const { createServer } = require("http");
const { initSockets } = require('./sockets');
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const convRoutes = require('./routes/conversations');
const msgRoutes = require('./routes/messages');

const app = express();
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/conversations', convRoutes);
app.use('/api/messages', msgRoutes);

const port = process.env.PORT || 3000;
const server = createServer(app);

// Socket init
initSockets(server);

async function start(){
  await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/chat', {
    useNewUrlParser: true,
    useUnifiedTopology: true
  });
  console.log('MongoDB connected');

  server.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });
}

start().catch(err => {
  console.error('Failed to start', err);
  process.exit(1);
});