const express = require('express');
const auth = require('../middleware/auth');
const Conversation = require('../models/Conversation');
const router = express.Router();

// Create or fetch private conversation between two users
router.post('/private', auth, async (req, res) => {
  const { otherUserId } = req.body;
  if(!otherUserId) return res.status(400).json({ error: 'otherUserId required' });

  // Try find existing private convo with both participants
  let convo = await Conversation.findOne({
    type: 'private',
    participants: { $all: [req.user._id, otherUserId], $size: 2 }
  });

  if(!convo){
    convo = new Conversation({ type: 'private', participants: [req.user._id, otherUserId] });
    await convo.save();
  }
  res.json(convo);
});

// List user conversations
router.get('/', auth, async (req, res) => {
  const convos = await Conversation.find({ participants: req.user._id })
    .populate('participants', 'name phone avatarUrl')
    .sort({ createdAt: -1 })
    .limit(100);
  res.json(convos);
});

module.exports = router;