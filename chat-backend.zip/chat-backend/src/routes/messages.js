const express = require('express');
const auth = require('../middleware/auth');
const Message = require('../models/Message');
const Conversation = require('../models/Conversation');
const multer = require('multer');
const upload = multer({ dest: '/tmp/uploads' }); // replace with S3 in prod
const router = express.Router();

// Get messages for a conversation (pagination)
router.get('/:conversationId', auth, async (req, res) => {
  const { conversationId } = req.params;
  const limit = Math.min(100, parseInt(req.query.limit) || 50);
  const before = req.query.before ? new Date(req.query.before) : null;

  const query = { conversation: conversationId };
  if(before) query.createdAt = { $lt: before };

  const messages = await Message.find(query)
    .sort({ createdAt: -1 })
    .limit(limit)
    .populate('sender', 'name phone avatarUrl')
    .lean();

  res.json(messages.reverse()); // oldest first
});

// Send message (REST fallback; real-time should also be done via sockets)
router.post('/:conversationId', auth, upload.single('file'), async (req, res) => {
  const { conversationId } = req.params;
  const { body, type='text' } = req.body;
  const conv = await Conversation.findById(conversationId);
  if(!conv) return res.status(404).json({ error: 'Conversation not found' });
  // TODO: check participant access

  let mediaUrl;
  if(req.file){
    // In production: upload to S3 and set mediaUrl; here we'll use local temp path
    mediaUrl = `/media/${req.file.filename}`;
  }

  const msg = new Message({
    conversation: conversationId,
    sender: req.user._id,
    body: body || '',
    media: mediaUrl,
    type
  });
  await msg.save();

  // TODO: publish to socket/redis for real-time delivery
  res.json(msg);
});

module.exports = router;