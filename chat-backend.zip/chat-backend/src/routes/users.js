const express = require('express');
const auth = require('../middleware/auth');
const User = require('../models/User');
const router = express.Router();

// Get current profile
router.get('/me', auth, async (req, res) => {
  res.json(req.user);
});

// Search users by phone/name (basic)
router.get('/search', auth, async (req, res) => {
  const q = req.query.q || '';
  const users = await User.find({
    $or: [
      { phone: q },
      { name: { $regex: q, $options: 'i' } },
      { email: { $regex: q, $options: 'i' } }
    ]
  }).limit(20).select('-passwordHash');
  res.json(users);
});

module.exports = router;